﻿using InterageApp.DTO;
using InterageApp.Models;
using InterageApp.Repository.Interfaces;
using InterageApp.Services.Interfaces;

namespace InterageApp.Services.Implementations
{
    public class ValidateUser : IValidateUser
    {
        private readonly IAuthValidateRepository _rep;
        public bool CheckUser(CredenciaisDto credenciais)
        {
            Usuario user = _rep.GetCredenciais(credenciais.Email);
            if (user.Senha == credenciais.Password) return true;
            return false;
        }
    }
}